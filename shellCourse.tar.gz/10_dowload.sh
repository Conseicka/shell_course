# !bin/bash
# Programa para ejemplificar el uso de la descarga de informacion desde internet utilizando el comando wget
echo "Descarga de informacion de internet"
wget https://github.com/git-for-windows/git/releases/download/v2.33.0.windows.1/Git-2.33.0-64-bit.exe
